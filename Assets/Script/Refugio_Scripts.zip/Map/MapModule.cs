﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class MapModule : MonoBehaviour
{
    public Tilemap[] tileMaps;   
    
    // Start is called before the first frame update
    void Start()
    {
        
    }
}
