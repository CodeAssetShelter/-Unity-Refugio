

Thank you for the purchase!!

This file created by exides.com team.

-----------------------------------------------------------------------------------
   

Get Started
------------

Main file contains: .pat file and 2 folders with png images.

Using Patterns:

   1. Open the FP1.pat
 
   2. double click on your layer for blending options

   3. click on pattern overlay and select desired pattern

   4.Enjoy!! 



for additional information please visit: WWW.exides.com
